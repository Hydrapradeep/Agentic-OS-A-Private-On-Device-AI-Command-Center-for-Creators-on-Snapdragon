// Tiny stand-in for an on-device model server, so you can test AI_MODE=local
// without Snapdragon hardware. It speaks the same OpenAI-compatible routes that
// a real Qualcomm AI Hub / Genie / QAIRT server would expose.
//   node scripts/mock-local-ai.js      (LLM :18181, speech-to-text :18182)
import http from "http";

function json(res, code, body) {
  res.writeHead(code, { "Content-Type": "application/json" });
  res.end(JSON.stringify(body));
}

http.createServer((req, res) => {
  if (req.method === "POST" && req.url === "/v1/chat/completions") {
    let raw = "";
    req.on("data", (c) => (raw += c));
    req.on("end", () => {
      const body = JSON.parse(raw || "{}");
      const last = body.messages?.at(-1)?.content ?? "";
      json(res, 200, { choices: [{ message: { role: "assistant",
        content: `[mock on-device model: ${body.model}] ${String(last).slice(0, 80)}` } }] });
    });
  } else json(res, 404, { error: { message: "not found" } });
}).listen(18181, () => console.log("mock LLM on :18181"));

http.createServer((req, res) => {
  if (req.method === "POST" && req.url === "/v1/audio/transcriptions") {
    req.resume();
    req.on("end", () => json(res, 200, { text: "mock transcription from on-device whisper" }));
  } else json(res, 404, { error: { message: "not found" } });
}).listen(18182, () => console.log("mock STT on :18182"));
